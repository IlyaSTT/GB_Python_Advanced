# print("Hello world!".__doc__)
# print(str.__doc__)
# Возвращают одинаковые данные

print("Hello world!".upper())
print("Hello world!".count('l'))

print(dir("Hello world!"))
help()  # symbols # >>=
