num = 42
name = 'Bob'
if num > 30:
    if num < 50:
        print('Вариант 1')
    elif name > 'Markus':
        print('Вариант 2')
    else:
        print('Вариант 3')
elif name < 'Markus':
    print('Вариант 4')
elif num != 42:
    print('Вариант 5')
else:
    print('Вариант 6')
