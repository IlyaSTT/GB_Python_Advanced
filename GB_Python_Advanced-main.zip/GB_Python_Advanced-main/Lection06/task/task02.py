from sys import argv

print('start')
print(argv)
print('stop')
