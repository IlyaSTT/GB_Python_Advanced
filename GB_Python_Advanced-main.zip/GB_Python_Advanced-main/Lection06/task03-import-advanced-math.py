# from my_math import base_math as bm
from my_math import base_math
from my_math.advanced_math import exp

x = base_math.div(10, 2)
# x = bm.div(12, 5)
z = exp(2, 3)

print(x, z)
