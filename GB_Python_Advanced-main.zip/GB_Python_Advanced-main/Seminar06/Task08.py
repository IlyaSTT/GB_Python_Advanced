# * на уровне пакета
# from new_package import *

# * на уровне модуля внутри пакета
from new_package.data_parser import *

# from new_package import Task06
# from new_package import data_parser
from random import *

# parse_data()
